globalThis.STUDIO_UPDATE_SOURCE = "https://github.com/loyuhsuan76-alt/PDF";
